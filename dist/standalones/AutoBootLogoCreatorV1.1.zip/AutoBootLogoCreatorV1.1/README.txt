NOTE: The 1 pixel border around your image will be the background color of 
you boot logo (i.e if your border is white, it will fill in the rest of the 
phone screen with white).

Step 1: Create the image (Option 1) -- recommended
Open up your favorite image editing tool and simply edit the Template.bmp file 
that I have provided to make your logo. When you are satisfied with the way it
looks, save it.  
Note that you can copy or rename the file and it won't make a difference 
as long as you make sure to drag your image to the script window

Step 1: Create the image (Option 2)
Open up Photoshop, paint, GIMP, or some equivalent and create a new image 
with dimensions 480 (width) X 182 (height). Create whatever you want as 
the image and then SAVE IT AS A 24-bit BMP FILE (this is important)

Step 2:
After you are done making your 24-bit .bmp (this will be the case if you
edited my provided file) start up the program by clicking BootImgToFlashZip.exe.

Step 2A (Contingency): 
If for some reason this doesn't work, I've also provided the compilied Python
script that you can run by typing 'python BootImgToFlashZip.pyc' from the 
command prompt. As it is a Python script (and not packaged like the .exe is),
you'll need Python to run it. You can get Python at:
 http://www.python.org/ftp/python/2.7.2/python-2.7.2.msi
if you don't have it already. You'll also need the PIL image library here:
http://effbot.org/downloads/PIL-1.1.7.win32-py2.7.exe

Step 3: 
After the script starts, just follow the 
instructions and it will do everything for you.  