DO NOT MODIFY THIS BOOTLOGO.ZIP!!

I don't know if it's just me, but sometimes I get an error that 
BootLogo.zip is in use. No matter what I try (killing processes, etc.)
it still happens. The only way I've found to fix the problem is to delete
BootLogo.zip and copy over a new one, hence this copy. Hopefully this helps
if it happens to you.